<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$userId = $_SESSION['user_id'];

// Database connection
$host = 'localhost';
$db   = 'diprella';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

// Handle unstar action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['unstar_file'])) {
    $fileId = $_POST['file_id'];
    $stmt = $pdo->prepare("UPDATE documents SET starred = FALSE WHERE id = ? AND user_id = ?");
    $stmt->execute([$fileId, $userId]);
    echo json_encode(['status' => 'success']);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Starred Documents | eSafeDocs</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <style>
    .starred-item {
      transition: all 0.2s;
    }
    .starred-item:hover {
      transform: translateX(5px);
    }
  </style>
</head>
<body class="bg-gray-100 p-4">
  <div class="max-w-5xl mx-auto">
    <div class="flex justify-between items-center mb-6">
      <h1 class="text-3xl font-bold">⭐ Starred Documents</h1>
      <a href="mydrive.php" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded">
        <i class="fas fa-arrow-left"></i> Back to My Drive
      </a>
    </div>
    
    <div class="bg-white rounded-lg shadow overflow-hidden">
      <div id="starred-list" class="divide-y divide-gray-200"></div>
    </div>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', () => {
      const starredList = document.getElementById('starred-list');
      
      function loadStarredFiles() {
        fetch('mydrive.php?list=1')
          .then(res => res.json())
          .then(files => {
            starredList.innerHTML = '';
            
            const starredFiles = files.filter(file => file.starred);
            
            if (starredFiles.length === 0) {
              starredList.innerHTML = `
                <div class="p-8 text-center text-gray-500">
                  <i class="fas fa-star text-4xl mb-4 text-gray-300"></i>
                  <p class="text-xl">No starred files found</p>
                </div>
              `;
              return;
            }

            starredFiles.forEach(file => {
              const div = document.createElement('div');
              div.className = 'starred-item p-4 hover:bg-gray-50 flex items-center justify-between';
              div.innerHTML = `
                <div class="flex items-center space-x-4">
                  <i class="fas fa-file text-blue-500 text-xl"></i>
                  <div>
                    <div class="font-medium">${file.filename}</div>
                    <div class="text-sm text-gray-500">Uploaded: ${file.uploaded_at}</div>
                  </div>
                </div>
                <button 
                  class="unstar-btn text-yellow-500 hover:text-yellow-600 p-2 rounded-full hover:bg-yellow-50"
                  onclick="unstarFile(${file.id}, this)"
                >
                  <i class="fas fa-star"></i>
                </button>
              `;
              
              // Make the whole item clickable except the unstar button
              div.addEventListener('click', (e) => {
                if (!e.target.closest('.unstar-btn')) {
                  window.open(file.filepath, '_blank');
                }
              });
              
              starredList.appendChild(div);
            });
          });
      }

      function unstarFile(fileId, button) {
        const formData = new FormData();
        formData.append('unstar_file', true);
        formData.append('file_id', fileId);

        fetch('starred.php', {
          method: 'POST',
          body: formData
        })
        .then(res => res.json())
        .then(result => {
          if (result.status === 'success') {
            button.closest('.starred-item').remove();
            if (document.querySelectorAll('.starred-item').length === 0) {
              starredList.innerHTML = `
                <div class="p-8 text-center text-gray-500">
                  <i class="fas fa-star text-4xl mb-4 text-gray-300"></i>
                  <p class="text-xl">No starred files found</p>
                </div>
              `;
            }
          } else {
            alert('Error unstarring file');
          }
        });
      }

      window.unstarFile = unstarFile;
      loadStarredFiles();
    });
  </script>
</body>
</html>