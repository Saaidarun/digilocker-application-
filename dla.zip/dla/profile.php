<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$user_id = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Profile Page</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      background-color: #f5f5f5;
      font-family: Arial, sans-serif;
    }

    .header {
      background-color: #333;
      color: #fff;
      padding: 15px;
      text-align: center;
      font-size: 24px;
      font-weight: bold;
    }

    .profile-container {
      width: 400px;
      margin: 40px auto;
      padding: 25px;
      background-color: #202020;
      border-radius: 10px;
      text-align: center;
      color: #fff;
      box-shadow: 0 0 10px rgba(255, 255, 255, 0.2);
    }

    .profile-container h2 {
      margin-bottom: 20px;
    }

    .profile-pic-container {
      width: 120px;
      height: 120px;
      border-radius: 50%;
      overflow: hidden;
      margin: 0 auto 15px;
      border: 3px solid #fff;
      background-color: #333;
      box-sizing: border-box;
      cursor: pointer;
    }

    .profile-pic-container img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      border-radius: 50%;
    }

    .form-group {
      margin-bottom: 15px;
      text-align: left;
    }

    .form-group label {
      display: block;
      margin-bottom: 5px;
      color: #fff;
    }

    .form-group input {
      width: 100%;
      padding: 8px;
      border: 1px solid #ccc;
      border-radius: 4px;
    }

    .button-group {
      margin-top: 20px;
    }

    .button-group button {
      margin: 5px;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      background-color: #ff5959;
      color: #fff;
      font-size: 14px;
    }

    .button-group button:hover {
      background-color: #ff3030;
    }

    #profile-details {
      margin-top: 20px;
      text-align: left;
      color: #fff;
    }

    #profile-details p {
      margin: 10px 0;
    }

    #profile-pic-display {
      width: 120px;
      height: 120px;
      border-radius: 50%;
      border: 3px solid #060606;
      object-fit: cover;
      background-color: #eceaea;
      display: block;
      margin: 0 auto 15px;
    }
  </style>
</head>
<body>
  <div class="profile-container">
    <h2>User Profile</h2>

    <div class="profile-pic-container">
      <img id="profile-pic-preview" src="default-profile.jpg" alt="Profile Picture" onclick="document.getElementById('profile-pic-upload').click()" />
      <input type="file" id="profile-pic-upload" accept="image/*" style="display: none;" />
    </div>

    <form id="profile-form" action="#" method="post" enctype="multipart/form-data">
      <div class="form-group">
        <label for="reg-number">Register Number</label>
        <input type="text" name="reg-number" id="reg-number" placeholder="Enter your register number" required/>
      </div>

      <div class="form-group">
        <label for="name">Full Name</label>
        <input type="text" name="name" id="name" placeholder="Enter your full name" required/>
      </div>

      <div class="form-group">
        <label for="email">Email Address</label>
        <input type="email" name="email" id="email" placeholder="Enter your email" required/>
      </div>

      <div class="form-group">
        <label for="phone">Phone Number</label>
        <input type="tel" name="phone" id="phone" placeholder="Enter your phone number" required/>
      </div>

      <div class="form-group">
        <label for="alt-phone">Optional Phone Number</label>
        <input type="tel" name="alt-phone" id="alt-phone" placeholder="Enter an optional phone number"/>
      </div>

      <div class="form-group">
        <label for="dob">Date of Birth</label>
        <input type="date" name="dob" id="dob" required/>
      </div>

      <div class="button-group">
        <button type="submit" id="save-button">Save Profile</button>
      </div>
    </form>

    <div id="profile-details" style="display: none;">
      <p><strong>Register Number:</strong> <span id="reg-number-display"></span></p>
      <p><strong>Full Name:</strong> <span id="name-display"></span></p>
      <p><strong>Email Address:</strong> <span id="email-display"></span></p>
      <p><strong>Phone Number:</strong> <span id="phone-display"></span></p>
      <p><strong>Optional Phone Number:</strong> <span id="alt-phone-display"></span></p>
      <p><strong>Date of Birth:</strong> <span id="dob-display"></span></p>

      <div class="button-group">
        <button type="button" id="home-button">Go Back to Home</button>
        <button type="button" id="logout-button">Logout</button>
        <button type="button" id="edit-button">Edit Profile</button>
      </div>
    </div>
  </div>

  <script>
    function loadProfile() {
      const savedProfile = localStorage.getItem("profile");
      if (savedProfile) {
        const profile = JSON.parse(savedProfile);
        document.getElementById('reg-number-display').textContent = profile.regNumber;
        document.getElementById('name-display').textContent = profile.name;
        document.getElementById('email-display').textContent = profile.email;
        document.getElementById('phone-display').textContent = profile.phone;
        document.getElementById('alt-phone-display').textContent = profile.altPhone;
        document.getElementById('dob-display').textContent = profile.dob;
        if (profile.profilePic) {
          document.getElementById('profile-pic-preview').src = profile.profilePic;
        }
        document.getElementById('profile-form').style.display = 'none';
        document.getElementById('profile-details').style.display = 'block';
      }
    }

    const profileForm = document.getElementById('profile-form');
    const profileDetails = document.getElementById('profile-details');
    const profilePicPreview = document.getElementById('profile-pic-preview');
    const profilePicUpload = document.getElementById('profile-pic-upload');

    const regNumberDisplay = document.getElementById('reg-number-display');
    const nameDisplay      = document.getElementById('name-display');
    const emailDisplay     = document.getElementById('email-display');
    const phoneDisplay     = document.getElementById('phone-display');
    const altPhoneDisplay  = document.getElementById('alt-phone-display');
    const dobDisplay       = document.getElementById('dob-display');

    const regNumberInput   = document.getElementById('reg-number');
    const nameInput        = document.getElementById('name');
    const emailInput       = document.getElementById('email');
    const phoneInput       = document.getElementById('phone');
    const altPhoneInput    = document.getElementById('alt-phone');
    const dobInput         = document.getElementById('dob');

    const homeButton   = document.getElementById('home-button');
    const logoutButton = document.getElementById('logout-button');
    const editButton   = document.getElementById('edit-button');

    window.addEventListener('DOMContentLoaded', loadProfile);

    profilePicUpload.addEventListener('change', function(e) {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = function(event) {
          profilePicPreview.src = event.target.result;
        };
        reader.readAsDataURL(file);
      }
    });

    profileForm.addEventListener('submit', function(e) {
      e.preventDefault();
      regNumberDisplay.textContent = regNumberInput.value;
      nameDisplay.textContent      = nameInput.value;
      emailDisplay.textContent     = emailInput.value;
      phoneDisplay.textContent     = phoneInput.value;
      altPhoneDisplay.textContent  = altPhoneInput.value;
      dobDisplay.textContent       = dobInput.value;

      const profile = {
        regNumber: regNumberInput.value,
        name: nameInput.value,
        email: emailInput.value,
        phone: phoneInput.value,
        altPhone: altPhoneInput.value,
        dob: dobInput.value,
        profilePic: profilePicPreview.src
      };

      localStorage.setItem("profile", JSON.stringify(profile));
      profileForm.style.display = 'none';
      profileDetails.style.display = 'block';
    });

    editButton.addEventListener('click', function() {
      const savedProfile = localStorage.getItem("profile");
      if (savedProfile) {
        const profile = JSON.parse(savedProfile);
        regNumberInput.value = profile.regNumber;
        nameInput.value      = profile.name;
        emailInput.value     = profile.email;
        phoneInput.value     = profile.phone;
        altPhoneInput.value  = profile.altPhone;
        dobInput.value       = profile.dob;
        if (profile.profilePic) {
          profilePicPreview.src = profile.profilePic;
        }
      }
      profileForm.style.display = 'block';
      profileDetails.style.display = 'none';
    });

    homeButton.addEventListener('click', function() {
      window.location.href = 'home.php';
    });

    logoutButton.addEventListener('click', function() {
      localStorage.removeItem("profile");
      window.location.href = 'login.php';
    });
  </script>
</body>
</html>
