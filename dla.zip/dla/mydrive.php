<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    die("Access denied. Please <a href='login.php'>login</a>.");
}
$userId = $_SESSION['user_id'];

// --- DATABASE CONNECTION ---
$host = 'localhost';
$db   = 'diprella';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

// --- HANDLE FILE UPLOAD ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // File Upload
    if (isset($_FILES['document'])) {
        $uploadDir = __DIR__ . '/uploads/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

        $fileName = basename($_FILES['document']['name']);
        $targetPath = $uploadDir . $fileName;

        if (move_uploaded_file($_FILES['document']['tmp_name'], $targetPath)) {
            $stmt = $pdo->prepare("INSERT INTO documents (filename, filepath, user_id) VALUES (?, ?, ?)");
            $stmt->execute([$fileName, 'uploads/' . $fileName, $userId]);
            echo "File uploaded & saved in database.";
        } else {
            echo "Failed to upload file.";
        }
        exit;
    }

    // File Deletion (move to trash)
    if (isset($_POST['delete_file'])) {
        $fileId = $_POST['file_id'];
        $stmt = $pdo->prepare("UPDATE documents SET deleted = TRUE WHERE id = ? AND user_id = ?");
        $stmt->execute([$fileId, $userId]);
        echo json_encode(['status' => 'success']);
        exit;
    }

    // File Rename
    if (isset($_POST['rename_file'], $_POST['file_id'], $_POST['new_name'])) {
        $fileId = $_POST['file_id'];
        $newName = basename($_POST['new_name']); // clean filename

        $stmt = $pdo->prepare("SELECT filepath FROM documents WHERE id = ? AND user_id = ? AND deleted = FALSE");
        $stmt->execute([$fileId, $userId]);
        $file = $stmt->fetch();

        if ($file) {
            $oldPath = __DIR__ . '/' . $file['filepath'];
            $dir = dirname($oldPath);
            $newPath = $dir . '/' . $newName;

            if (file_exists($oldPath)) {
                if (rename($oldPath, $newPath)) {
                    $stmt = $pdo->prepare("UPDATE documents SET filename = ?, filepath = ? WHERE id = ? AND user_id = ?");
                    $stmt->execute([$newName, 'uploads/' . $newName, $fileId, $userId]);
                    echo json_encode(['status' => 'success']);
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'File system rename failed']);
                }
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Original file not found']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Unauthorized or file not found']);
        }
        exit;
    }

    // Toggle Starred Status
    if (isset($_POST['toggle_star'])) {
        $fileId = $_POST['file_id'];
        
        // First get current starred status
        $stmt = $pdo->prepare("SELECT starred FROM documents WHERE id = ? AND user_id = ? AND deleted = FALSE");
        $stmt->execute([$fileId, $userId]);
        $file = $stmt->fetch();
        
        if ($file) {
            $newStarredStatus = $file['starred'] ? 0 : 1;
            $stmt = $pdo->prepare("UPDATE documents SET starred = ? WHERE id = ? AND user_id = ?");
            $stmt->execute([$newStarredStatus, $fileId, $userId]);
            echo json_encode(['status' => 'success', 'starred' => $newStarredStatus]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'File not found or unauthorized']);
        }
        exit;
    }
}

// --- HANDLE FILE LISTING ---
if (isset($_GET['list'])) {
    $stmt = $pdo->prepare("SELECT id, filename, filepath, uploaded_at, starred FROM documents WHERE user_id = ? AND deleted = FALSE ORDER BY starred DESC, uploaded_at DESC");
    $stmt->execute([$userId]);
    $files = $stmt->fetchAll();

    header('Content-Type: application/json');
    echo json_encode($files);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>eSafeDocs - My Drive</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</head>
<body class="bg-gray-100 p-4">
    <div class="max-w-5xl mx-auto">
        <div class="flex justify-between items-center mb-4">
            <h1 class="text-3xl font-bold">📁 eSafeDocs - My Drive</h1>
            <div class="space-x-2">
                <a href="starred.php" class="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded">
                    <i class="fas fa-star"></i> Starred
                </a>
                <a href="trash.php" class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded">
                    <i class="fas fa-trash"></i> Trash
                </a>
            </div>
        </div>
        
        <div class="mb-4">
            <button onclick="document.getElementById('document').click();" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded">
                <i class="fas fa-upload"></i> Upload File
            </button>
        </div>
        <form id="uploadForm" style="display:none;" enctype="multipart/form-data">
            <input type="file" id="document" name="document" />
        </form>
        <div id="fileArea" class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4"></div>
    </div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        loadFilesFromServer();
    });

    document.getElementById('document').addEventListener('change', function () {
        const file = this.files[0];
        if (!file) return;

        const formData = new FormData();
        formData.append('document', file);

        fetch('', {
            method: 'POST',
            body: formData
        })
        .then(res => res.text())
        .then(msg => {
            alert(msg);
            loadFilesFromServer();
            document.getElementById('uploadForm').reset();
        });
    });

    function loadFilesFromServer() {
        fetch('?list=1')
            .then(res => res.json())
            .then(files => {
                const fileArea = document.getElementById('fileArea');
                fileArea.innerHTML = '';

                if (files.length === 0) {
                    fileArea.innerHTML = '<p class="text-gray-500">No files found.</p>';
                    return;
                }

                files.forEach(file => {
                    const div = document.createElement('div');
                    div.className = 'bg-white p-4 rounded shadow hover:shadow-lg transition relative';
                    div.innerHTML = `
                        <div class="flex items-center space-x-2">
                            <i class="fas fa-file text-blue-500 text-lg"></i>
                            <span class="font-semibold">${file.filename}</span>
                        </div>
                        <div class="text-sm text-gray-500 mt-1">Uploaded: ${file.uploaded_at}</div>
                        <button 
                            class="absolute top-2 right-2 text-red-600 hover:text-red-800"
                            onclick="event.stopPropagation(); deleteFile(${file.id}, this);"
                        >
                            <i class="fas fa-trash-alt"></i>
                        </button>
                        <button 
                            class="absolute top-2 right-10 text-yellow-600 hover:text-yellow-800"
                            onclick="event.stopPropagation(); renameFile(${file.id}, '${file.filename}');"
                        >
                            <i class="fas fa-pen"></i>
                        </button>
                        <button 
                            class="absolute top-2 right-18 ${file.starred ? 'text-yellow-500' : 'text-gray-400'} hover:text-yellow-500"
                            onclick="event.stopPropagation(); toggleStar(${file.id}, this);"
                        >
                            <i class="fas fa-star"></i>
                        </button>
                    `;
                    div.onclick = () => {
                        window.open(file.filepath, '_blank');
                    };
                    fileArea.appendChild(div);
                });
            });
    }

    function deleteFile(fileId, button) {
        if (!confirm('Are you sure you want to move this file to trash?')) return;

        const formData = new FormData();
        formData.append('delete_file', true);
        formData.append('file_id', fileId);

        fetch('', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(result => {
            if (result.status === 'success') {
                button.closest('div').remove();
            } else {
                alert('Error moving file to trash: ' + (result.message || 'Unknown error'));
            }
        });
    }

    function renameFile(fileId, currentName) {
        const newName = prompt("Enter new filename:", currentName);
        if (!newName || newName === currentName) return;

        const formData = new FormData();
        formData.append('rename_file', true);
        formData.append('file_id', fileId);
        formData.append('new_name', newName);

        fetch('', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(result => {
            if (result.status === 'success') {
                alert('File renamed successfully');
                loadFilesFromServer();
            } else {
                alert('Error renaming file: ' + (result.message || 'Unknown error'));
            }
        });
    }

    function toggleStar(fileId, button) {
        const formData = new FormData();
        formData.append('toggle_star', true);
        formData.append('file_id', fileId);

        fetch('', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(result => {
            if (result.status === 'success') {
                // Toggle the star color
                if (result.starred) {
                    button.classList.remove('text-gray-400');
                    button.classList.add('text-yellow-500');
                } else {
                    button.classList.remove('text-yellow-500');
                    button.classList.add('text-gray-400');
                }
            } else {
                alert('Error updating star status: ' + (result.message || 'Unknown error'));
            }
        });
    }
</script>
</body>
</html>