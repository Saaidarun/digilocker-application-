<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$user_id = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>eSafeDocs - Home</title>
  <!-- Inline CSS -->
  <style>
    /* Global Styles */
    body {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
      background-color: #f5f5f5;
    }
    /* Sidebar */
    .sidebar {
      position: fixed;
      top: 0;
      left: 0;
      width: 220px;
      height: 100vh;
      background-color: #2a2a2a;
      padding: 20px 10px;
      color: #fff;
    }
    .sidebar h2 {
      text-align: center;
      margin-bottom: 20px;
      font-size: 20px;
    }
    .sidebar ul {
      list-style: none;
      padding: 0;
    }
    .sidebar ul li {
      margin-bottom: 10px;
    }
    .sidebar ul li a {
      color: #fff;
      text-decoration: none;
      padding: 10px;
      display: block;
      border-radius: 4px;
    }
    .sidebar ul li a:hover {
      background-color: #444;
    }
    /* Main Content */
    .main-content {
      margin-left: 240px; /* Sidebar width + gap */
      padding: 40px;
    }
    /* Search Bar */
    .search-bar {
      margin-bottom: 20px;
    }
    .search-bar input {
      width: 80%;
      padding: 8px 12px;
      font-size: 14px;
      border: 1px solid #ccc;
      border-radius: 4px;
    }
    .search-bar button {
      padding: 8px 12px;
      font-size: 14px;
      border: none;
      background-color: #1a73e8;
      color: #fff;
      border-radius: 4px;
      cursor: pointer;
    }
    /* Content Area */
#contentArea {
  height: calc(100vh - 100px); /* Adjust based on your header height */
  overflow: hidden;
}

#contentFrame {
  width: 100%;
  height: 100%;
  border: none;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}
    /* Profile Section */
    .profile-section {
      position: fixed;
      top: 20px;
      right: 20px;
    }
    .profile-icon {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      overflow: hidden;
      cursor: pointer;
      border: 2px solid #fff;
    }
    .profile-icon img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    .profile-icon:hover {
  box-shadow: 0 0 8px rgba(255, 255, 255, 0.4);
}
  </style>
</head>
<body>
  <!-- Sidebar -->
<div class="sidebar">
  <h2>eSafeDocs</h2>
  <ul>
    <li><a href="#" onclick="loadContent('home')">Home</a></li>
    <li><a href="#" onclick="loadContent('mydrive')">My Documents</a></li>
    <li><a href="#" onclick="loadContent('starred')">Starred</a></li>
    <li><a href="#" onclick="loadContent('trash')">Trash</a></li>
  </ul>
</div>

  <!-- Main Content Area -->
  <div class="main-content">
    <!-- Search Bar -->
    <div class="search-bar">
      <input type="text" id="searchInput" placeholder="Search documents...">
      <button onclick="searchFiles()">🔍</button>
      <div id="searchResults"></div>
    </div>
    
    <!-- Content will be loaded here -->
    <div id="contentArea">
      <h1>Welcome to eSafeDocs</h1>
      <p>Select an option from the sidebar to view content.</p>
    </div>
  </div>

  <!-- Profile Section -->
  <div class="profile-section">
  <div class="profile-icon" onclick="window.location.href='profile.php'">
    <img src="profilepic.avif" alt="Profile">
  </div>
</div>

  <!-- External JS -->
  <script src="style.js"></script>
  <script>
    // Dynamic content mapping
    const pageContents = {
  'home': `
    <div class="content-card">
      <h1>Home</h1>
      <p>This is the home page content.</p>
    </div>
  `,
  'mydrive': '<iframe id="contentFrame" src="mydrive.php"></iframe>',
  'starred': '<iframe id="contentFrame" src="starred.php"></iframe>',
  'application status': '<iframe id="contentFrame" src="applicationst.php"></iframe>',
  'shared': '<iframe id="contentFrame" src="shared.php"></iframe>',
  'trash': '<iframe id="contentFrame" src="trash.php"></iframe>'
};

function loadContent(page) {
  // Prevent default anchor behavior
  event.preventDefault();
  
  // Load content into the main area
  const contentArea = document.getElementById('contentArea');
  contentArea.innerHTML = pageContents[page] || contentArea.innerHTML;
  
  // Add history entry
  window.history.pushState({page}, '', `#${page}`);
}

// Handle browser back/forward
window.onpopstate = function(event) {
  if (event.state?.page) {
    document.getElementById('contentArea').innerHTML = pageContents[event.state.page];
  }
};
  </script>

  <!-- Live-server reload script -->
  <script>
    if ('WebSocket' in window) {
      (function () {
        function refreshCSS() {
          var sheets = Array.from(document.getElementsByTagName("link"));
          sheets.forEach(elem => {
            var parent = elem.parentElement || document.head;
            parent.removeChild(elem);
            var url = elem.href.replace(/(&|\?)_cacheOverride=\d+/, '');
            elem.href = url + (url.includes('?') ? '&' : '?') + '_cacheOverride=' + Date.now();
            parent.appendChild(elem);
          });
          
        }
        var proto = window.location.protocol === 'http:' ? 'ws://' : 'wss://';
        var address = proto + window.location.host + window.location.pathname + '/ws';
        var socket = new WebSocket(address);
        socket.onmessage = msg => msg.data === 'reload' ? window.location.reload() : msg.data === 'refreshcss' && refreshCSS();
        if (sessionStorage && !sessionStorage.getItem('firstReloadLogged')) {
          console.log('Live reload enabled.');
          sessionStorage.setItem('firstReloadLogged', true);
        }
      })();
    } else console.error('WebSocket not supported for live-reload.');
    // Replace the profile picture on home page if stored in localStorage
  window.addEventListener('DOMContentLoaded', function () {
    const savedProfile = localStorage.getItem("profile");
    if (savedProfile) {
      try {
        const profile = JSON.parse(savedProfile);
        if (profile.profilePic) {
          const profileImg = document.querySelector(".profile-icon img");
          if (profileImg) {
            profileImg.src = profile.profilePic;
          }
        }
      } catch (e) {
        console.error("Error parsing profile from localStorage:", e);
      }
    }
  });
  </script>
</body>
</html>