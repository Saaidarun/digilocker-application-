<?php
session_start();

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "diprella";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$error = '';
$success = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['signup'])) {
        // Signup handling
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        $password = $_POST['password'];
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Invalid email format";
        } else {
            $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $stmt->store_result();
            
            if ($stmt->num_rows > 0) {
                $error = "Email already exists";
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $insert = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'user')");
                $insert->bind_param("sss", $name, $email, $hashed_password);
                if ($insert->execute()) {
                    $success = "Registration successful! Please login.";
                } else {
                    $error = "Registration failed";
                }
            }
        }
    } elseif (isset($_POST['login'])) {
        // Login handling
        $email = trim($_POST['email']);
        $password = $_POST['password'];
        $is_admin = isset($_POST['admin']) && $_POST['admin'] == 1;

        $stmt = $conn->prepare("SELECT id, password, role FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->bind_result($user_id, $hashed_password, $role);
        $stmt->fetch();
        
        if ($user_id && password_verify($password, $hashed_password)) {
            if ($is_admin && $role !== 'admin') {
                $error = "Admin access denied";
            } else {
                $_SESSION['user_id'] = $user_id;
                $_SESSION['role'] = $role;
                
                if ($role === 'admin') {
                    header("Location: admin-dashboard.php");
                } else {
                    header("Location: home.php");
                }
                exit();
            }
        } else {
            $error = "Invalid credentials";
        }
    } elseif (isset($_POST['reset_password'])) {
        // Password reset handling
        $email = trim($_POST['email']);
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        if ($new_password !== $confirm_password) {
            $error = "Passwords don't match";
        } else {
            $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $stmt->store_result();
            
            if ($stmt->num_rows > 0) {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $update = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
                $update->bind_param("ss", $hashed_password, $email);
                if ($update->execute()) {
                    $success = "Password updated successfully";
                } else {
                    $error = "Password reset failed";
                }
            } else {
                $error = "Email not found";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Diprella – Sign In / Sign Up</title>
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    
    body {
      background: #0d0d0d;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      padding: 20px;
    }
    
    .container {
      background-color: #fff;
      border-radius: 10px;
      box-shadow: 0 14px 28px rgba(0, 0, 0, 0.25), 0 10px 10px rgba(0, 0, 0, 0.22);
      position: relative;
      overflow: hidden;
      width: 900px;
      max-width: 100%;
      min-height: 550px;
    }
    
    .form-container {
      position: absolute;
      top: 0;
      height: 100%;
      width: 50%;
      padding: 0 50px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
      transition: all 0.6s ease-in-out;
    }
    
    .sign-in-container {
      left: 0;
      z-index: 2;
    }
    
    .sign-up-container {
      left: 0;
      opacity: 0;
      z-index: 1;
    }
    
    .container.right-panel-active .sign-in-container {
      transform: translateX(100%);
      opacity: 0;
      z-index: 1;
    }
    
    .container.right-panel-active .sign-up-container {
      transform: translateX(100%);
      opacity: 1;
      z-index: 2;
    }
    
    form {
      background: #fff;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      width: 100%;
      padding: 20px 0;
    }
    
    .logo {
      margin-bottom: 30px;
    }
    
    .logo img {
      height: 50px;
      width: auto;
    }
    
    h1 {
      font-weight: bold;
      margin: 0;
    }
    
    h2 {
      margin-bottom: 20px;
      color: #ff8f8f;
    }
    
    .admin-login h2 {
      color: #4a90e2;
    }
    
    .input-group {
      margin-bottom: 15px;
      width: 100%;
      text-align: left;
    }
    
    .input-group label {
      margin-bottom: 5px;
      color: #555;
      display: block;
      font-size: 14px;
    }
    
    .input-group input {
      background: #f0f0f0;
      border: none;
      border-radius: 5px;
      padding: 12px 15px;
      width: 100%;
      font-size: 14px;
      color: #333;
    }
    
    .input-group input:focus {
      outline: none;
      background: #e0e0e0;
    }
    
    a.forgot-password {
      color: #ff8f8f;
      text-decoration: none;
      font-size: 0.9em;
      margin: 10px 0;
      display: inline-block;
      cursor: pointer;
    }
    
    button {
      border: none;
      border-radius: 5px;
      padding: 12px 45px;
      font-size: 14px;
      font-weight: bold;
      cursor: pointer;
      transition: all 0.3s ease;
      width: 100%;
    }
    
    button[type="submit"] {
      background-color: #ff8f8f;
      color: #fff;
      margin-top: 15px;
    }
    
    button[type="submit"]:hover {
      background-color: #ff7a7a;
      transform: translateY(-2px);
    }
    
    .overlay-container {
      position: absolute;
      top: 0;
      left: 50%;
      width: 50%;
      height: 100%;
      overflow: hidden;
      transition: transform 0.6s ease-in-out;
      z-index: 100;
    }
    
    .container.right-panel-active .overlay-container {
      transform: translateX(-100%);
    }
    
    .overlay {
      background: linear-gradient(to right, #ff8f8f, #ff6b6b);
      color: #fff;
      position: relative;
      left: -100%;
      height: 100%;
      width: 200%;
      transform: translateX(0);
      transition: transform 0.6s ease-in-out;
    }
    
    .container.right-panel-active .overlay {
      transform: translateX(50%);
    }
    
    .overlay-panel {
      position: absolute;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 0 40px;
      text-align: center;
      top: 0;
      height: 100%;
      width: 50%;
      transition: transform 0.6s ease-in-out;
    }
    
    .overlay-left {
      transform: translateX(-20%);
    }
    
    .container.right-panel-active .overlay-left {
      transform: translateX(0);
    }
    
    .overlay-right {
      right: 0;
      transform: translateX(0);
    }
    
    .container.right-panel-active .overlay-right {
      transform: translateX(20%);
    }
    
    .overlay-panel p {
      font-size: 14px;
      margin: 20px 0 30px;
    }
    
    button.ghost {
      background-color: transparent;
      border: 2px solid #fff;
      color: #fff;
      padding: 12px 30px;
      font-size: 14px;
      border-radius: 5px;
      cursor: pointer;
      transition: all 0.3s ease;
    }
    
    button.ghost:hover {
      background-color: rgba(255, 255, 255, 0.2);
      transform: translateY(-2px);
    }
    
    .modal {
      display: none;
      position: fixed;
      z-index: 200;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgba(0,0,0,0.5);
      justify-content: center;
      align-items: center;
    }
    
    .modal-content {
      background-color: #fff;
      border-radius: 10px;
      padding: 30px;
      width: 90%;
      max-width: 400px;
      text-align: center;
      position: relative;
      box-shadow: 0 5px 15px rgba(0,0,0,0.3);
    }
    
    .modal-content h2 {
      margin-bottom: 20px;
      color: #ff8f8f;
    }
    
    .modal-content .input-group {
      margin-bottom: 15px;
    }
    
    .close {
      position: absolute;
      top: 15px;
      right: 20px;
      font-size: 24px;
      font-weight: bold;
      color: #aaa;
      cursor: pointer;
    }
    
    .close:hover {
      color: #000;
    }
    
    .alert {
      padding: 10px 15px;
      border-radius: 5px;
      margin-bottom: 20px;
      width: 100%;
      font-size: 14px;
    }
    
    .alert-error {
      background-color: #ffebee;
      color: #c62828;
      border: 1px solid #ef9a9a;
    }
    
    .alert-success {
      background-color: #e8f5e9;
      color: #2e7d32;
      border: 1px solid #a5d6a7;
    }
  </style>
</head>
<body>
  <div class="container" id="container">
    <!-- Sign Up Form -->
    <div class="form-container sign-up-container">
      <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <h2>Create Account</h2>
        <?php if($error && isset($_POST['signup'])): ?>
          <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>
        <?php if($success && isset($_POST['signup'])): ?>
          <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        <div class="input-group">
          <label for="name">Name</label>
          <input type="text" name="name" required>
        </div>
        <div class="input-group">
          <label for="email">Email</label>
          <input type="email" name="email" required>
        </div>
        <div class="input-group">
          <label for="password">Password</label>
          <input type="password" name="password" required>
        </div>
        <button type="submit" name="signup">SIGN UP</button>
      </form>
    </div>

    <!-- Sign In Form -->
    <div class="form-container sign-in-container">
      <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <div class="logo">
          <img src="profilepic.avif" alt="Diprella">
        </div>
        <h2 id="formTitle">Diprella</h2>
        <?php if($error && (isset($_POST['login']) || isset($_POST['reset_password']))): ?>
          <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>
        <?php if($success && isset($_POST['reset_password'])): ?>
          <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        <input type="hidden" name="admin" id="adminInput" value="0">
        <div class="input-group">
          <input type="email" name="email" placeholder="Email" required>
        </div>
        <div class="input-group">
          <input type="password" name="password" placeholder="Password" required>
        </div>
        <a class="forgot-password" id="forgotPasswordLink">Reset your password?</a>
        <a class="forgot-password" id="adminLoginLink">Admin login</a>
        <button type="submit" name="login">Login</button>
      </form>
    </div>

    <!-- Overlay -->
    <div class="overlay-container">
      <div class="overlay">
        <div class="overlay-panel overlay-left">
          <h1>Welcome Back!</h1>
          <p>To keep connected with us please login with your personal info</p>
          <button class="ghost" id="signIn">Login</button>
        </div>
        <div class="overlay-panel overlay-right">
          <h1>Hello, Friend!</h1>
          <p>Enter your personal details and start journey with us</p>
          <button class="ghost" id="signUp">SIGN UP</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Forgot Password Modal -->
  <div id="forgotPasswordModal" class="modal">
    <div class="modal-content">
      <span class="close" id="closeModal">&times;</span>
      <h2>Reset Password</h2>
      <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <div class="input-group">
          <label for="email">Enter your registered email</label>
          <input type="email" name="email" required>
        </div>
        <div class="input-group">
          <label for="new_password">New Password</label>
          <input type="password" name="new_password" required>
        </div>
        <div class="input-group">
          <label for="confirm_password">Confirm New Password</label>
          <input type="password" name="confirm_password" required>
        </div>
        <button type="submit" name="reset_password">Reset Password</button>
      </form>
    </div>
  </div>

  <script>
    // Right Panel Toggle
    const signUpButton = document.getElementById('signUp');
    const signInButton = document.getElementById('signIn');
    const container = document.getElementById('container');

    signUpButton.addEventListener('click', () => {
      container.classList.add("right-panel-active");
    });

    signInButton.addEventListener('click', () => {
      container.classList.remove("right-panel-active");
    });

    // Admin Login Toggle
    const adminLoginLink = document.getElementById('adminLoginLink');
    const adminInput = document.getElementById('adminInput');
    const formTitle = document.getElementById('formTitle');

    adminLoginLink.addEventListener('click', (e) => {
      e.preventDefault();
      if (adminInput.value === '0') {
        adminInput.value = '1';
        formTitle.textContent = 'Diprella Admin';
        formTitle.style.color = '#4a90e2';
        adminLoginLink.textContent = 'User login';
      } else {
        adminInput.value = '0';
        formTitle.textContent = 'Diprella';
        formTitle.style.color = '#ff8f8f';
        adminLoginLink.textContent = 'Admin login';
      }
    });

    // Modal Handling
    const forgotPasswordLink = document.getElementById('forgotPasswordLink');
    const forgotModal = document.getElementById('forgotPasswordModal');
    const closeModal = document.getElementById('closeModal');

    forgotPasswordLink.addEventListener('click', (e) => {
      e.preventDefault();
      forgotModal.style.display = 'flex';
    });

    closeModal.addEventListener('click', () => {
      forgotModal.style.display = 'none';
    });

    window.addEventListener('click', (e) => {
      if (e.target === forgotModal) {
        forgotModal.style.display = 'none';
      }
    });
  </script>
</body>
</html>
<?php
$conn->close();
?>