<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$userId = $_SESSION['user_id'];

// Database connection
$host = 'localhost';
$db   = 'diprella';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

// Handle restore and permanent delete actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['restore_file'])) {
        $fileId = $_POST['file_id'];
        $stmt = $pdo->prepare("UPDATE documents SET deleted = FALSE, deleted_at = NULL WHERE id = ? AND user_id = ?");
        $stmt->execute([$fileId, $userId]);
        echo json_encode(['status' => 'success']);
        exit;
    }
    
    if (isset($_POST['permanent_delete_file'])) {
        $fileId = $_POST['file_id'];
        
        // First get file path
        $stmt = $pdo->prepare("SELECT filepath FROM documents WHERE id = ? AND user_id = ?");
        $stmt->execute([$fileId, $userId]);
        $file = $stmt->fetch();
        
        if ($file) {
            // Delete from database
            $stmt = $pdo->prepare("DELETE FROM documents WHERE id = ? AND user_id = ?");
            $stmt->execute([$fileId, $userId]);
            
            // Delete file from server
            $filePath = __DIR__ . '/' . $file['filepath'];
            if (file_exists($filePath)) {
                unlink($filePath);
            }
            
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'File not found']);
        }
        exit;
    }
}

// Get deleted files
$stmt = $pdo->prepare("SELECT id, filename, filepath, uploaded_at, deleted_at FROM documents WHERE user_id = ? AND deleted = TRUE ORDER BY deleted_at DESC");
$stmt->execute([$userId]);
$deletedFiles = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Trash | eSafeDocs</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <style>
    .trash-item {
      transition: all 0.2s;
    }
    .trash-item:hover {
      transform: translateX(5px);
    }
  </style>
</head>
<body class="bg-gray-100 p-4">
  <div class="max-w-5xl mx-auto">
    <div class="flex justify-between items-center mb-6">
      <h1 class="text-3xl font-bold">🗑️ Trash</h1>
      <a href="mydrive.php" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded">
        <i class="fas fa-arrow-left"></i> Back to My Drive
      </a>
    </div>
    
    <div class="bg-white rounded-lg shadow overflow-hidden">
      <?php if (empty($deletedFiles)): ?>
        <div class="p-8 text-center text-gray-500">
          <i class="fas fa-trash-alt text-4xl mb-4 text-gray-300"></i>
          <p class="text-xl">Trash is empty</p>
        </div>
      <?php else: ?>
        <div class="divide-y divide-gray-200">
          <?php foreach ($deletedFiles as $file): ?>
            <div class="trash-item p-4 hover:bg-gray-50 flex items-center justify-between">
              <div class="flex items-center space-x-4">
                <i class="fas fa-file text-blue-500 text-xl"></i>
                <div>
                  <div class="font-medium"><?= htmlspecialchars($file['filename']) ?></div>
                  <div class="text-sm text-gray-500">
                    Deleted: <?= $file['deleted_at'] ?? 'Unknown' ?>
                  </div>
                </div>
              </div>
              <div class="space-x-2">
                <button 
                  onclick="restoreFile(<?= $file['id'] ?>, this)"
                  class="text-green-600 hover:text-green-800 p-2 rounded-full hover:bg-green-50"
                  title="Restore"
                >
                  <i class="fas fa-undo"></i>
                </button>
                <button 
                  onclick="permanentDelete(<?= $file['id'] ?>, this)"
                  class="text-red-600 hover:text-red-800 p-2 rounded-full hover:bg-red-50"
                  title="Permanently delete"
                >
                  <i class="fas fa-trash"></i>
                </button>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <script>
    function restoreFile(fileId, button) {
      if (!confirm('Are you sure you want to restore this file?')) return;

      const formData = new FormData();
      formData.append('restore_file', true);
      formData.append('file_id', fileId);

      fetch('trash.php', {
        method: 'POST',
        body: formData
      })
      .then(res => res.json())
      .then(result => {
        if (result.status === 'success') {
          button.closest('.trash-item').remove();
          // If no more items, show empty state
          if (document.querySelectorAll('.trash-item').length === 0) {
            document.querySelector('.divide-y').innerHTML = `
              <div class="p-8 text-center text-gray-500">
                <i class="fas fa-trash-alt text-4xl mb-4 text-gray-300"></i>
                <p class="text-xl">Trash is empty</p>
              </div>
            `;
          }
        } else {
          alert('Error restoring file');
        }
      })
      .catch(error => {
        console.error('Error:', error);
        alert('Error restoring file');
      });
    }

    function permanentDelete(fileId, button) {
      if (!confirm('Are you sure you want to permanently delete this file? This cannot be undone.')) return;

      const formData = new FormData();
      formData.append('permanent_delete_file', true);
      formData.append('file_id', fileId);

      fetch('trash.php', {
        method: 'POST',
        body: formData
      })
      .then(res => res.json())
      .then(result => {
        if (result.status === 'success') {
          button.closest('.trash-item').remove();
          // If no more items, show empty state
          if (document.querySelectorAll('.trash-item').length === 0) {
            document.querySelector('.divide-y').innerHTML = `
              <div class="p-8 text-center text-gray-500">
                <i class="fas fa-trash-alt text-4xl mb-4 text-gray-300"></i>
                <p class="text-xl">Trash is empty</p>
              </div>
            `;
          }
        } else {
          alert('Error deleting file');
        }
      })
      .catch(error => {
        console.error('Error:', error);
        alert('Error deleting file');
      });
    }
  </script>
</body>
</html>