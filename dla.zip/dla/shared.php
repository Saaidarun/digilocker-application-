<?php
$servername = "localhost";
$username = "root";
$password = "";  // Default XAMPP has empty password
$dbname = "diprella";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle file upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $target_dir = "uploads/";
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    
    $filename = basename($_FILES['file']['name']);
    $target_file = $target_dir . $filename;
    $filesize = $_FILES['file']['size'];
    $filetype = $_FILES['file']['type'];
    $uniqueToken = bin2hex(random_bytes(16));

    if (move_uploaded_file($_FILES['file']['tmp_name'], $target_file)) {
        $stmt = $conn->prepare("INSERT INTO files (filename, filesize, filetype, unique_token) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $filename, $filesize, $filetype, $uniqueToken);
        
        if ($stmt->execute()) {
            echo "File uploaded successfully!";
        } else {
            echo "Error uploading file to database.";
        }
        $stmt->close();
    } else {
        echo "Error uploading file.";
    }
    exit;
}

// Handle file listing
if (isset($_GET['action']) && $_GET['action'] === 'list') {
    header('Content-Type: application/json');
    
    $sql = "SELECT id, filename, filesize, unique_token FROM files";
    $result = $conn->query($sql);

    $files = array();
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $files[] = $row;
        }
    }
    echo json_encode($files);
    exit;
}

// Handle file download
if (isset($_GET['download'])) {
    $token = $_GET['download'];
    
    $stmt = $conn->prepare("SELECT filename FROM files WHERE unique_token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $filename = $row['filename'];
        $filepath = "uploads/" . $filename;
        
        if (file_exists($filepath)) {
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="'.basename($filepath).'"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($filepath));
            readfile($filepath);
            exit;
        }
    }
    echo "File not found!";
    exit;
}

// HTML Interface
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shared Drive</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f1f1f1;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        .file-list {
            margin-top: 20px;
        }

        .file-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }

        .file-item:hover {
            background-color: #f9f9f9;
        }

        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        input[type="file"] {
            padding: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Shared Drive</h1>
        
        <form id="uploadForm" enctype="multipart/form-data">
            <input type="file" name="file" id="fileInput">
            <button type="submit">Upload</button>
        </form>

        <div class="file-list" id="fileList">
            <!-- Files will be loaded here -->
        </div>
    </div>

    <script>
        document.getElementById('uploadForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData();
            const fileInput = document.getElementById('fileInput');
            
            formData.append('file', fileInput.files[0]);
            
            fetch('shared.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                alert(data);
                loadFiles();
            })
            .catch(error => console.error(error));
        });

        function loadFiles() {
            fetch('shared.php?action=list')
            .then(response => response.json())
            .then(files => {
                const fileList = document.getElementById('fileList');
                fileList.innerHTML = '';
                
                files.forEach(file => {
                    const fileItem = document.createElement('div');
                    fileItem.className = 'file-item';
                    fileItem.innerHTML = `
                        <span>${file.filename}</span>
                        <div>
                            <button onclick="shareFile('${file.unique_token}')">Share</button>
                            <button onclick="downloadFile('${file.unique_token}')">Download</button>
                        </div>
                    `;
                    fileList.appendChild(fileItem);
                });
            });
        }

        function shareFile(token) {
            const link = `${window.location.origin}/shared.php?download=${token}`;
            prompt('Share this link:', link);
        }

        function downloadFile(token) {
            window.location.href = `shared.php?download=${token}`;
        }

        // Load files when page loads
        loadFiles();
    </script>
</body>
</html>
<?php $conn->close(); ?>